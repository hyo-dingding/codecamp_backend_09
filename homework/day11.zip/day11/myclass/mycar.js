class MyCar {
    name = Volvo;
    power = 20;
    color = pink;

    StartDrive = () => {
        console.log("차가 출발합니다");
    };
    StopDrive = () => {
        console.log("차가 멈춥니다.");
    };
}
